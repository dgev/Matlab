gamma=1/4;
eps=1/1000;
a=-3;
b=5;
f=@(x)x^2-6*x;
GSS(f,a,b,gamma,eps)