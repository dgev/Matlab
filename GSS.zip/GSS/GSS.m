function F = GSS(f,a,b,gamma,eps)
ak=a;
bk=b;
while abs(bk-ak)>=eps
Ak=ak+gamma.*(bk-ak);
Bk=bk-gamma.*(bk-ak);
if f(Ak)<f(Bk)
    bk=Bk;
end
if f(Ak)>=f(Bk)
    ak=Ak;
end
end
F=(bk+ak)./2;
end

