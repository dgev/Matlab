n = [2,4,10,20,50,100];
f=@(x)sin(x);
g=@(x)exp(x);
h=@(x)atan(x);
for i=1:6
T = ['Composite Trapezoid rule for n=',num2str(n(i))];
S = ['Composite Simpson�s rule for n=',num2str(n(i))];    
disp(T)   
Trapezoid_Uniform(f,0,pi,n(i))
disp('Error for the Composite Trapezoid rule')
abs(Trapezoid_Uniform(f,0,pi,n(i))-integral(f,0,pi))
disp(S)
Simpson_Uniform(f,0,pi,2)
disp('Error for the Composite Simpson�s rule')
abs(Simpson_Uniform(f,0,pi,n(i))-integral(f,0,pi))

disp(T)
Trapezoid_Uniform(g,0,1,n(i))
disp('Error for the Composite Trapezoid rule')
abs(Trapezoid_Uniform(g,0,1,n(i))-integral(g,0,1))
disp(S)
Simpson_Uniform(g,0,1,n(i))
disp('Error for the Composite Simpson�s rule')
abs(Simpson_Uniform(g,0,1,n(i))-integral(g,0,1))

disp(T) 
Trapezoid_Uniform(h,0,pi,n(i))
disp('Error for the Composite Trapezoid rule')
abs(Trapezoid_Uniform(h,0,pi,n(i))-integral(h,0,pi))
disp(S)
Simpson_Uniform(h,0,pi,n(i))
disp('Error for the Composite Simpson�s rule')
abs(Simpson_Uniform(h,0,pi,n(i))-integral(h,0,pi))
end