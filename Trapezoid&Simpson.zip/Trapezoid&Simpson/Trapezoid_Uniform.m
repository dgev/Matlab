function I = Trapezoid_Uniform(f,a,b,n)
x=linspace(a,b,n+1);
I=0;
for k=0:n-1
    I=I+(f(x(k+1))+f(x(k+2)))*(b-a)/(2*n);
end

end

