syms x
f=legendreP(5,x) ;
roots = solve(f, x);
r = [          
 -(5/9 - (2*2^(1/2)*35^(1/2))/63)^(1/2), -((2*2^(1/2)*35^(1/2))/63 + 5/9)^(1/2),  0, (5/9 - (2*2^(1/2)*35^(1/2))/63)^(1/2), ((2*2^(1/2)*35^(1/2))/63 + 5/9)^(1/2)];
nodes=2*r+1;
tweights=[0,0,0,0,0];
for k=1:5
    h=1;
    for i = 1:5        
        if i~=k            
        h = h.*((x-r(i))./(r(k)-r(i)));        
        end        
    end   
    
    lk=matlabFunction(h);
    tweights(k)=integral(lk,-1,1);
end
g=@(x)exp(-x.^2).*cos(x);
GQR=0;
rweights=2*tweights;
for t=1:5
    GQR = GQR+rweights(t)*g(nodes(t));
end
sims=Simpson_Uniform(g,-1,3,2);
I=integral(g,-1,3);
disp('The value of an integral by using the Quadrature Rule obtained in b is')
disp(GQR)
disp('The approximate value of the same integral by using the Simpson�s Rule for n = 2 is')
disp(sims)
disp('The value calculated using the MatLab�s built-in function integral is')
disp(I)
disp('Error for the Composite Simpson�s rule')
abs(sims-I)
disp('Error for the Quadrature Rule')
abs(GQR-I)
