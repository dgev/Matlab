function I = Simpson_Uniform(f,a,b,n)
x=linspace(a,b,2*n+1);
I=0;
for k=0:n-1
    I=I+((f(x(2*k+1)))+4*f(x(2*k+2))+f(x(2*k+3)))*(b-a)/(6*n);
end

end

