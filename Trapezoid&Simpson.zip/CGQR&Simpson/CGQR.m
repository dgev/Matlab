function F = CGQR(f,a,b,n)
x=linspace(a,b,n+1);
F = 0;
for k=1:n
 newa=x(k);
 newb=x(k+1);
 F= F+GQR(f,newa,newb,2);
end
end

