syms x
f=legendreP(5,x) ;
root = solve(f, x);
roots = root;
roots(1)=root(2);
roots(2)=root(3);
roots(3)=root(1);
r = [          
 -(5/9 - (2*2^(1/2)*35^(1/2))/63)^(1/2), -((2*2^(1/2)*35^(1/2))/63 + 5/9)^(1/2),  0, (5/9 - (2*2^(1/2)*35^(1/2))/63)^(1/2), ((2*2^(1/2)*35^(1/2))/63 + 5/9)^(1/2)];
weights=[0,0,0,0,0];
for k=1:5
    h=1;
    for i = 1:5        
        if i~=k            
        h = h.*((x-r(i))./(r(k)-r(i)));        
        end        
    end       
    lk=matlabFunction(h);
    weights(k)=integral(lk,-1,1);
end
disp('The Gaussian quadrature nodes on interval [?1,1] are')
disp(roots)
disp('Gaussian quadrature weights on the interval [?1,1] are')
disp(weights)