function F = steepest(f,v,x0)
syms h
eps = 10^-5;
g = gradient(f,v);
hi = num2cell(x0 - h.*transpose(subs(g,v,x0)));
fi = subs(f,v,hi);
dfi = diff(fi, {h});
gfi = matlabFunction(fi);
hk = fminsearch(gfi, 0);
xk = double(x0-hk.*transpose(subs(g,v,x0)));
fik = transpose(subs(fi,h,hk));
fi0 = transpose(subs(fi,h,0));
dfi0 = hk.*transpose(subs(dfi,h,0));
fiy = transpose(subs(fi,h,1.5*hk));
i = 1;
while norm(xk-x0,2) > eps
x0 = xk;
if ((fik > fi0 + eps*dfi0) || (fiy < fi0 + 1.5*eps*dfi0))
     hk  = 0.5*hk;
    fik = transpose(subs(fi,h,hk));
    dfi0 = hk.*transpose(subs(dfi,h,0));
    fiy = transpose(subs(fi,h,1.5*hk));
end
xk = double(x0-hk.*transpose(subs(g,v,x0)));
i = i+1;
end
i
F = xk;
end