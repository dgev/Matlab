syms x1 x2
f = 100*(x2-x1.^2).^2 + (1-x1).^2;
v = [x1, x2];
x0 = [1,0];
x11 = [-1,0];
x22 = [-1,-1];
steepest(f,v,x0)
steepest(f,v,x11)
steepest(f,v,x22)
x0 = [0,0];
x3 = [-1,1];
x4 = [3,9];
Newton(f,v,x0)
Newton(f,v,x3)
Newton(f,v,x4)

% As we can see from the results Newton's method converges to the exact
% minimum point after 3 iterations. However, Steepest Descent algorithm
% tends to different points after a lot of number of iterations(8,10,15).


