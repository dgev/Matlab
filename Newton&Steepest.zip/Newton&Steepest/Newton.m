function F = Newton(f,v,x)
eps = 10^-5;
x0 = transpose(x);
h = inv(subs(hessian(f), v, x));
g = subs(gradient(f), v, x);
x1 = x0 - mtimes(h,g);
i = 1;
while norm(x1-x0,2) > eps
     x0 = x1;
     h = inv(subs(hessian(f),v,transpose(x0)));
     g = subs(gradient(f),v,transpose(x0));
     x1 = x0 - mtimes(h,g);
     i = i + 1;
end
i
F = double(x0);
end