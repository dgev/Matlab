syms x1 x2
f = 100*(x2-x1.^2).^2 + (1-x1).^2;
x0 = [-2,2];
v = [x1, x2];
conjugate(f,v,x0)
