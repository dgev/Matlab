function F = Frobenius(a)
n = size(a,1);
F = 0;
for i=1:n
   MN = 0;
    for j=1:n
       MN = MN + a(i,j).*a(i,j);
    end
    F = F + MN; 
end
F = sqrt(F);
end

