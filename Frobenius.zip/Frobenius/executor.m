a=[1 2 3; 0 5 4; 2 1 3];
H = hilb(10);
a1 = [0 0 1 2; 3 0 5 4; 1 1 1 2; 1 3 2 2];
Frobenius(a)
Frobenius(H)
Frobenius(a1)

