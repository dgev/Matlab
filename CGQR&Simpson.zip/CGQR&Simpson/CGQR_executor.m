f=@(x)x.^5;
g=@(x)sin(x)./x;
n=[1,2,10];
for i =1:3
    disp('Composite Gaussian Quadrature Rule for n =')
    disp(n(i))
CGQR(f,0,1,n(i))
end
n1=[1,2,3,4];
for i =1:4
    disp('Composite Gaussian Quadrature Rule for n =')
    disp(n1(i))
CGQR(g,0,1,n1(i))
end