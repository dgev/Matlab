function f = LeastSquares(m,x,y)
f1=0;
f2=0;
syms a b
for i=1:m
    f1 = f1 + (x(i).*a+b-y(i)).*x(i);
    f2 = f2 + (x(i).*a+b-y(i));
end
sol = solve([f1, f2], [a,b]);
aSol = sol.a;
bSol = sol.b;
f = aSol + bSol;
line = @(x0) aSol*x0 + bSol;
fplot(line, [-1,6], 'b');
hold on
scatter(x,y,'filled','r');
end