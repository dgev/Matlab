f = @(x) atan(x);
x = [-2, -1, -0.5, 0, 0.3, 0.7, 1, 1.5, 2, 3];
p = polyfit(x, f(x), 9);
g = poly2sym(p);
g
xList = [0.3, 0.9, 2.8];
polyn = polyval(p, xList);
func = f(xList);
result = func-polyn;
result
figure(1)
plot(x,f(x),'*', 'MarkerEdgeColor','r');
hold on
fplot(f,[-2,3],'b');
hold on
fplot(g,[-2,3],'g');
figure(2)
fplot(f-g,[-2,3]);
interval =(-2:0.01:3);
result1 = abs(f(interval)-polyval(p,interval));
final_result = max(result1);
final_result

