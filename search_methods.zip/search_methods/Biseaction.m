function F = Biseaction(f,fprime,a,b,n)
ak=a;
bk=b;
xk = (a+b)/2;
for i = 1:n
   if(fprime(xk)==0)
      break
   end
   if fprime(xk)<0
        ak = xk;
   end
   if fprime(xk)>0
        bk = xk;
   end
    xk=(ak+bk)/2;
end
F = f(xk);
end