f = @(x) log(x.^2 - 1.6*x +3);
h = @(x) (x-1).*exp(-2*x.^2+4*x);
real1 = f(0.8);
real2 = h(0.5);
fprime = @(x) (2*x-1.6)/(x.^2-1.6*x+3);
fprimeprime = @(x) (2*(x.^2-1.6+3)+(2*x-1.6)*(2*x-1.6))/((x.^2-1.6*x+3)^2);
hprime = @(x) exp(-2*x.^2+4*x)*(-4*x^2+8*x-3);
hprimeprime = @(x) exp(-2*x.^2+4*x)*((-8*x+8)+(-4*x^2+8*x-3)*(-4*x+x));
f1 = abs(GSS(f,0,3,2)-real1);
f2 = abs(GSS(h,0,3,2)-real2);
f3 = abs(GSS(h,-1,1,2)-real2);
n = 2;
T = table(n,f1,f2,f3);
for n = [4,8,16]
f1 = abs(GSS(f,0,3,n)-real1);
f2 = abs(GSS(h,0,3,n)-real2);
f3 = abs(GSS(h,-1,1,n)-real2);
CurrentT = table(n,f1,f2,f3);
T = [T;CurrentT];
end
T

n = 2;
f1 = abs(Fib(f,0,3,n)-real1);
f2 = abs(Fib(h,0,3,n)-real2);
f3 = abs(Fib(h,-1,1,n)-real2);
T = table(n,f1,f2,f3);
for n = [4,8,16]
f1 = abs(Fib(f,0,3,n)-real1);
f2 = abs(Fib(h,0,3,n)-real2);
f3 = abs(Fib(h,-1,1,n)-real2);
CurrentT = table(n,f1,f2,f3);
T = [T;CurrentT];
end
T

n = 2;
f1 = abs(Newton(f,fprime,fprimeprime,0,3,n)-real1);
f2 = abs(Newton(h,hprime,hprimeprime,0,3,n)-real2);
f3 = abs(Newton(h,hprime,hprimeprime,-1,1,n)-real2);
T = table(n,f1,f2,f3);

for n = [4,8,16]
f1 = abs(Newton(f,fprime,fprimeprime,0,3,n)-real1);
f2 = abs(Newton(h,hprime,hprimeprime,0,3,n)-real2);
f3 = abs(Newton(h,hprime,hprimeprime,-1,1,n)-real2);
CurrentT = table(n,f1,f2,f3);
T = [T;CurrentT];
end
T

n = 2;
f1 = abs(Biseaction(f,fprime,0,3,n)-real1);
f2 = abs(Biseaction(h,hprime,0,3,n)-real2);
f3 = abs(Biseaction(h,hprime,-1,1,n)-real2);
T = table(n,f1,f2,f3);

for n = [4,8,16]
f1 = abs(Biseaction(f,fprime,0,3,n)-real1);
f2 = abs(Biseaction(h,hprime,0,3,n)-real2);
f3 = abs(Biseaction(h,hprime,-1,1,n)-real2);
CurrentT = table(n,f1,f2,f3);
T = [T;CurrentT];
end
T

% From the results we can see that the best method is the Newton's method,
% since it is converging to the real value more quickly, compared to
% others. We can notice this trend from the errors which are getting considerably
% smaller when n gets bigger and bigger. 
% Golden Section Search method is in the second place, since its errors are
% small than Fibonacci's errors. Fibonacci is in the third place, and
% Bisection method is at the end, because for f2 on the interval (0,3) it
% fails to approximate the real minimum point. The cause behind this, is
% that f2 has two critical points on (0,3), and at the first iteration x0 =
% 1.5, which is a local maximum point for our function, therefore fprime at
% this point is 0. As a result the loop breaks, so the method fails to
% approximate our minimum point. On the other hand, Bisection method
% succeeds to compute the minimum point when interval is (-1,1), where
% there is a single critical point. We can say that it is the best method
% among others for computing the minimum point of f3.

