function F = Newton(f,fprime,fprimeprime,a,b,n)
xk = (b-a)/n;
for i = 1:n
    xk = xk - (fprime(xk))./(fprimeprime(xk));
end
F = f(xk);
end