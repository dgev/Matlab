function F = GSS(f,a,b,n)
r = 0.382;
ak=a;
bk=b;
for i = 1:n
Ak=ak+r.*(bk-ak);
Bk=bk-r.*(bk-ak);
if f(Ak)<f(Bk)
    bk=Bk;
end
if f(Ak)>=f(Bk)
    ak=Ak;
end
end
F = f((bk+ak)./2);
end