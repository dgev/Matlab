function F = Fib(f,a,b,n)
ak=a;
bk=b;   
for i = 1:n
    rk = 1 - (fibonacci(n+2-i))./(fibonacci(n+3-i));
Ak=ak+rk.*(bk-ak);
Bk=bk-rk.*(bk-ak);
if f(Ak)<f(Bk)
    bk=Bk;
end
if f(Ak)>=f(Bk)
    ak=Ak;
end
end
F = f((bk+ak)./2);
end